﻿using System;
using System.Collections.Generic;
using System.Linq;

public class AddCommand : ICommand
{
    public List<IWeapon> Execute(string[] args, List<IWeapon> weapons)
    {
        var weaponName = args[0];
        var weapon = weapons.First(w => w.Name.Equals(weaponName));

        var socketIndex = int.Parse(args[1]);

        var gemData = args[2].Split();
        GemClarity clarity;
        var ifParsed = GemClarity.TryParse(gemData[0], out clarity);
        var gemType = gemData[1];

        if (ifParsed)
        {
            var classType = Type.GetType(gemType);
            var gem = (IGem)Activator.CreateInstance(classType, new object[] { clarity });
            weapon.AddGem(gem, socketIndex);
        }

        return weapons;
    }
}