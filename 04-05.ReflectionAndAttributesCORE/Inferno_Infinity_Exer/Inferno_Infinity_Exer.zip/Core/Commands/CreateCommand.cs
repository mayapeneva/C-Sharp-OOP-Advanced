﻿using System;
using System.Collections.Generic;
using System.Linq;

public class CreateCommand : ICommand
{
    public List<IWeapon> Execute(string[] args, List<IWeapon> weapons)
    {
        var weaponData = args[0].Split();
        var weaponType = weaponData[1];
        Rarity weaponRarity;
        var ifparsed = Rarity.TryParse(weaponData[0], out weaponRarity);
        var weaponName = args[1];

        if (ifparsed)
        {
            var classType = Type.GetType(weaponType);
            var weapon = (IWeapon)Activator.CreateInstance(classType, new object[] { weaponName, weaponRarity });
            weapons.Add(weapon);
        }

        return weapons;
    }
}