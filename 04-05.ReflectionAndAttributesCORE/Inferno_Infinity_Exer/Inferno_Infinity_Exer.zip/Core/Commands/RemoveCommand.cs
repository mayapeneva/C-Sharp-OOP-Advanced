﻿using System.Collections.Generic;
using System.Linq;

public class RemoveCommand : ICommand
{
    public List<IWeapon> Execute(string[] args, List<IWeapon> weapons)
    {
        var weaponName = args[0];
        var socketIndex = int.Parse(args[1]);
        var weapon = weapons.First(w => w.Name.Equals(weaponName));
        weapon.RemoveGem(socketIndex);

        return weapons;
    }
}