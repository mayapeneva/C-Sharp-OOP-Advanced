﻿using System;
using System.Collections.Generic;
using System.Linq;

public class Engine
{
    private List<IWeapon> weapons = new List<IWeapon>();

    public void Run()
    {
        string input;
        while ((input = Console.ReadLine()) != "END")
        {
            var tokens = input.Split(';').ToArray();
            if (tokens[0] != "Print")
            {
                var commandName = tokens[0] + "Command";
                var args = tokens.Skip(1).ToArray();

                var commandType = Type.GetType(commandName);
                var command = (ICommand)Activator.CreateInstance(commandType);
                this.weapons = command.Execute(args, this.weapons);
            }
            else
            {
                var weapon = this.weapons.First(w => w.Name.Equals(tokens[1]));
                Console.WriteLine(weapon);
            }
        }
    }
}