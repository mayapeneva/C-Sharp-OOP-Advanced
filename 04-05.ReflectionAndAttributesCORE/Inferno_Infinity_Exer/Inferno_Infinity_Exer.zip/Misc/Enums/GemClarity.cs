﻿public enum GemClarity
{
    Chipped = 1,
    Regular,
    Perfect = 5,
    Flawless = 10
}