﻿public enum Rarity
{
    Common = 1,
    Uncommon,
    Rare,
    Epic = 5
}