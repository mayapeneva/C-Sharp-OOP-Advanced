﻿using System.Collections.Generic;

public interface ICommand
{
    List<IWeapon> Execute(string[] args, List<IWeapon> weapons);
}