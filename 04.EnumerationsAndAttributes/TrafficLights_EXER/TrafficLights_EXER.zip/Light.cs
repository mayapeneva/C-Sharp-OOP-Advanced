﻿namespace TrafficLights_EXER
{
    public enum Light
    {
        Red,
        Green,
        Yellow
    }
}