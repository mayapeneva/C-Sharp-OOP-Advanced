﻿using System;
using NUnit.Framework;

[TestFixture]
public class Class1
{
    [Test]
    public void AxeLosesDurabilityAfterAttack()
    {
        Axe axe = new Axe(1, 1);
        Dummy dummy = new Dummy(20, 20);

        axe.Attack(dummy);

        Assert.AreEqual(0, axe.DurabilityPoints, "Axe Durability doesn't change after attack");
    }

    public void AttackWithABrokenAxe()
    {
        Axe axe = new Axe(1, 1);
        Dummy dummy = new Dummy(20, 20);

        axe.Attack(dummy);

        Assert.Throws<InvalidOperationException>(() => axe.Attack(dummy));
    }
}