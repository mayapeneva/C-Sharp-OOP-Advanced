﻿namespace Logger.Entities.Enums
{
    public enum ReportLevel
    {
        Info,
        Warning,
        Error,
        Critical,
        Fatal
    }
}