﻿public abstract class AbstractCommand : ICommand
{
    private string name;
    private IManager heroManager;

    protected AbstractCommand(IManager heroManager, string name)
    {
        this.name = name;
        this.heroManager = heroManager;
    }

    public string Name
    {
        get { return this.name; }
    }

    public IManager HeroManager
    {
        get { return this.heroManager; }
    }

    public abstract string Execute();
}