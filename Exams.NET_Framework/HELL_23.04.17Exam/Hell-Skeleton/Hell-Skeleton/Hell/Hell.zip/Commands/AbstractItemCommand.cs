﻿public abstract class AbstractItemCommand : AbstractCommand
{
    private string heroName;
    private long strengthBonus;
    private long agilityBonus;
    private long intelligenceBonus;
    private long hitpointsBonus;
    private long damageBonus;

    protected AbstractItemCommand(IManager heroManager, string name, string heroName, long strengthBonus, long agilityBonus, long intelligenceBonus, long hitpointsBonus, long damageBonus)
        : base(heroManager, name)
    {
        this.heroName = heroName;
        this.strengthBonus = strengthBonus;
        this.agilityBonus = agilityBonus;
        this.intelligenceBonus = intelligenceBonus;
        this.hitpointsBonus = hitpointsBonus;
        this.damageBonus = damageBonus;
    }

    public string HeroName { get { return this.heroName; } }
    public long StrengthBonus { get { return this.strengthBonus; } }
    public long AgilityBonus { get { return this.agilityBonus; } }
    public long IntelligenceBonus { get { return this.intelligenceBonus; } }
    public long HitpointsBonus { get { return this.hitpointsBonus; } }
    public long DamageBonus { get { return this.damageBonus; } }
}