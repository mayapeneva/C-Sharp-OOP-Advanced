﻿public abstract class AbstractItem : IItem
{
    private string name;
    private long strengthBonus;
    private long agilityBonus;
    private long intelligenceBonus;
    private long hitpointsBonus;
    private long damageBonus;

    protected AbstractItem(string name, long strengthBonus, long agilityBonus, long intelligenceBonus, long hitpointsBonus, long damageBonus)
    {
        this.name = name;
        this.strengthBonus = strengthBonus;
        this.agilityBonus = agilityBonus;
        this.intelligenceBonus = intelligenceBonus;
        this.hitpointsBonus = hitpointsBonus;
        this.damageBonus = damageBonus;
    }

    public string Name
    {
        get { return this.name; }
    }

    public long StrengthBonus
    {
        get { return this.strengthBonus; }
    }

    public long AgilityBonus
    {
        get { return this.agilityBonus; }
    }

    public long IntelligenceBonus
    {
        get { return this.intelligenceBonus; }
    }

    public long HitPointsBonus
    {
        get { return this.hitpointsBonus; }
    }

    public long DamageBonus
    {
        get { return this.damageBonus; }
    }
}