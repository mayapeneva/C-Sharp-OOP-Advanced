﻿public interface IConstants
{
}