﻿public interface IInputReader
{
    string ReadLine();
}