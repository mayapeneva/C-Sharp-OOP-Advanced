﻿public class AutomaticMachine : Ammunition
{
    private const double Weight = 6.3;

    public AutomaticMachine(string name) 
        : base(name, Weight)
    {
    }
}