﻿public class Easy : Mission
{
    private const double enduranceRequired = 20;

    public Easy(string name, double scoreToComplete)
        : base(name, enduranceRequired, scoreToComplete)
    {
    }
}