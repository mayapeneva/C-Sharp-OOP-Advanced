﻿public class Hard : Mission
{
    private const double enduranceRequired = 80;

    public Hard(string name, double scoreToComplete) : base(name, enduranceRequired, scoreToComplete)
    {
    }
}