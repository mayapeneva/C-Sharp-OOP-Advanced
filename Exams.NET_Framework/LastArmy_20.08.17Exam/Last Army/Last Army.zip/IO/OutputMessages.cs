﻿public class OutputMessages
{
    public const string MissionDeclined = "Mission declined - {Name}";

    public const string MissionSuccessful = "Mission completed - {Name}";

    public const string MissionOnHold = "Mission on hold - {Name}";
    public static string SoldierToString { get; set; }
}