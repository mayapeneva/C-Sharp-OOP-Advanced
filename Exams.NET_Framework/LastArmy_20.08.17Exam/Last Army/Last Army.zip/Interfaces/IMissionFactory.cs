﻿public interface IMissionFactory
{
    IMission CreateMission(string difficultyLevel, double neededPoints);
}
