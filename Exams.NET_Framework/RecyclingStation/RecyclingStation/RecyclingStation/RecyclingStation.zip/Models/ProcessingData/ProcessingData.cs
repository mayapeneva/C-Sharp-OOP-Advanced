﻿using RecyclingStation.WasteDisposal.Interfaces;

namespace RecyclingStation.Models.ProcessingData
{
    public class ProcessingData : IProcessingData
    {
        private double energyBalance;
        private double capitalBalance;

        public double EnergyBalance
        {
            get => this.energyBalance;
            set => this.energyBalance = value;
        }

        public double CapitalBalance
        {
            get => this.capitalBalance;
            set => this.capitalBalance = value;
        }
    }
}