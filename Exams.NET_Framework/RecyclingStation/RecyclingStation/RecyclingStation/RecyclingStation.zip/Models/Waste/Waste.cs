﻿using RecyclingStation.WasteDisposal.Interfaces;

namespace RecyclingStation.Models.Waste
{
    public abstract class Waste : IWaste
    {
        private string name;
        private double volumePerKg;
        private double weight;

        protected Waste(string name, double weight, double volumePerKg)
        {
            this.name = name;
            this.volumePerKg = volumePerKg;
            this.weight = weight;
        }

        public string Name { get => this.name; }
        public double VolumePerKg { get => this.volumePerKg; }
        public double Weight { get => this.weight; }
        public double TotalVolume { get => this.weight * this.volumePerKg; }
    }
}