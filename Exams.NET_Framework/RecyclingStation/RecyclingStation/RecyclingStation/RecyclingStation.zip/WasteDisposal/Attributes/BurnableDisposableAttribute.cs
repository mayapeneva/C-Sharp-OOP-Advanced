﻿namespace RecyclingStation.WasteDisposal.Attributes
{
    public class BurnableDisposableAttribute : DisposableAttribute
    {
    }
}