﻿namespace RecyclingStation.WasteDisposal.Attributes
{
    public class RecyclableDisposableAttribute : DisposableAttribute
    {
    }
}