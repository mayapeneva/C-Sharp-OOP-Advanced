﻿namespace RecyclingStation.WasteDisposal.Attributes
{
    public class StorableDisposableAttribute : DisposableAttribute
    {
    }
}